module.exports = {
  LOGIN_TYPE: {
    GOOGLE: "google",
    LOCAL: "local",
    FACEBOOK: "facebook",
  },
};
